<?php
include("db_conex.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = mysqli_real_escape_string($conex, $_POST['nombre']);
    $apellidos = mysqli_real_escape_string($conex, $_POST['apellido']);
    $fecha_nacimiento = date('Y-m-d');
    $correo_electronico = mysqli_real_escape_string($conex, $_POST['email']);
    $telefono = mysqli_real_escape_string($conex, $_POST['telefono']);
    $domicilio = mysqli_real_escape_string($conex, $_POST['domicilio']);

    $consulta = "INSERT INTO clientes(nombre, apellidos, fecha_nacimiento, correo_electronico, telefono, domicilio) VALUES ('$nombre', '$apellidos', '$fecha_nacimiento', '$correo_electronico', '$telefono', '$domicilio')";

    $resultado = mysqli_query($conex, $consulta);

    if ($resultado) {
	    ?>
	    <div style="border-radius: 10px; display: flex; justify-content: cenetr; align-items: center; flex-direction: column;">
		    <h3 style="font-family: Arial; padding: 30px; background-color: #94FF8D">Te has inscrito correctamente</h3>

		    <a href="../red_culinary_formulario.php" style="border-radius: 10px; font-family: Arial; padding: 30px; background-color: #E2E3E2; text-decoration: none;">Volver atras</a>
	    </div>
	    <?php
	} else {
	    ?>
	    <h3>ERROR: <?php echo mysqli_error($conex); ?></h3>
	    <?php
	}

}

?>
