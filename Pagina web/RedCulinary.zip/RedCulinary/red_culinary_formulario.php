<?php
	include("conex/enviar_datos.php");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>RED CULINARY SHUSI</title>

	<link rel="stylesheet" type="text/css" href="css/red_culinary_formulario.css">
	<link rel="shortcut icon" href="images/logo-default1-140x57.png"/>
</head>
<body>
	<header>
		<div id="izquierda_header"><img src="images/logo-default1-140x57.png"><h1>RED CULINARY SUSHI - FORMULARIO</h1></div>
		<div id="derecha_header">
			<ul>
				<a href="index.html"><li>Volver atras</li></a>
			</ul>
		</div>
	</header>

	<div id="contenido">
		<div id="formulario">
			<form method="post" action="conex/enviar_datos.php">
				<h1>FORMULARIO</h1>
				<input type="text" name="nombre" placeholder="Tu nombre">
				<input type="text" name="apellido" placeholder="Tu apellido">
				<input type="text" name="domicilio" placeholder="Tu domicilio">
				<input type="email" name="email" placeholder="Tu email">
				<input type="date" name="fecha">
				
				<input type="number" name="telefono" placeholder="Tu telefono">
				<input type="submit" name="enviar" value="Verificar reserva">
			</form>
		</div>

	</div>
</body>
</html>