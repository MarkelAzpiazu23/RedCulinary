<?php
	$conex = mysqli_connect("database-1.cxymoooksu50.us-east-1.rds.amazonaws.com", "ubuntu", "ubuntuubuntu", "red_culinary_sushi");
?>